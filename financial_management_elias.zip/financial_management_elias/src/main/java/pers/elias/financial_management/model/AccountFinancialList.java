package pers.elias.financial_management.model;

public class AccountFinancialList {
    public static String[] accountFinancialList = {
            "现金账户",
            "金融账户",
            "信用账户",
            "负债账户"
    };
}
