package pers.elias.financial_management.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pers.elias.financial_management.model.AccountCurrent;
import pers.elias.financial_management.service.ITotalAmountCalculateService;
import pers.elias.financial_management.utils.AmountSumUtil;
import pers.elias.financial_management.utils.KeepTwoDecimals;
import java.util.List;
import java.util.Map;

@Service
public class TotalAmountCalculateService implements ITotalAmountCalculateService {
    @Autowired
    private TotalAmountService totalAmountService;

    /**
     * 计算日收支总额
     */
    @Override
    public Double calculateDailyInEx(AccountCurrent accountCurrent) {
        return AmountSumUtil.getAmountSum(totalAmountService.selectDailyInEx(accountCurrent));
    }

    /**
     * 计算月收支总额
     */
    @Override
    public Double calculateMonthlyInEx(AccountCurrent accountCurrent) {
        return AmountSumUtil.getAmountSum(totalAmountService.selectMonthlyInEx(accountCurrent));
    }

    /**
     * 计算年收支总额
     */
    @Override
    public Double calculateYearlyInEx(AccountCurrent accountCurrent) {
        return AmountSumUtil.getAmountSum(totalAmountService.selectYearlyInEx(accountCurrent));
    }

    /**
     * 计算账本收支总额
     */
    @Override
    public Double calculateAllInEx(Map<String, Object> map) {
        return AmountSumUtil.getAmountSum(totalAmountService.selectAllInEx(map));

    }

    /**
     * 计算总负债
     */
    @Override
    public Double calculateAllDebts(List<AccountCurrent> accountCurrentList) {
        double allDebts = 0;
        for(AccountCurrent accountCurrent: accountCurrentList){
            accountCurrent.setInExStatus("收");
            Double amountIn = AmountSumUtil.getAmountSum(totalAmountService.selectAccountAllInEx(accountCurrent));
            accountCurrent.setInExStatus("支");
            Double amountEx = AmountSumUtil.getAmountSum(totalAmountService.selectAccountAllInEx(accountCurrent));
            Double debts = KeepTwoDecimals.calculateKeepTwoDeci(amountIn - amountEx);
            allDebts = KeepTwoDecimals.calculateKeepTwoDeci(allDebts + debts);
        }
        return Math.abs(allDebts);//如果结果是负数，则取绝对值转正数

    }

    /**
     * 计算一级金融账户收支总额
     */
    @Override
    public Double calculateAccountAllInEx(AccountCurrent accountCurrent) {
        return AmountSumUtil.getAmountSum(totalAmountService.selectAccountAllInEx(accountCurrent));
    }

    /**
     * 计算子账户收支总额
     */
    @Override
    public Double calculateSubAccountAllInEx(AccountCurrent accountCurrent) {
        return AmountSumUtil.getAmountSum(totalAmountService.selectSubAccountAllInEx(accountCurrent));
    }

    /**
     * 计算二级分类收支总额
     */
    @Override
    public Double calculateSecondCategoryAllInEx(Map<String, Object> map) {
        return AmountSumUtil.getAmountSum(totalAmountService.selectSecondCategoryAllInEx(map));
    }
}
