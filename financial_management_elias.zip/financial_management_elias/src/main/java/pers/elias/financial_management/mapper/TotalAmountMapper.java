package pers.elias.financial_management.mapper;

import org.springframework.stereotype.Repository;
import pers.elias.financial_management.model.AccountCurrent;

import java.util.List;
import java.util.Map;

@Repository
public interface TotalAmountMapper {
    /**
     * 查询日收支
     */
    List<Double> selectDailyInEx(AccountCurrent accountCurrent);

    /**
     * 查询月收支
     */
    List<Double> selectMonthlyInEx(AccountCurrent accountCurrent);

    /**
     * 查询年收支
     */
    List<Double> selectYearlyInEx(AccountCurrent accountCurrent);

    /**
     * 查询所有收支
     */
    List<Double> selectAllInEx(Map<String, Object> map);

    /**
     * 查询一级账户收支
     */
    List<Double> selectAccountAllInEx(AccountCurrent accountCurrent);

    /**
     * 查询二级账户收支
     */
    List<Double> selectSubAccountAllInEx(AccountCurrent accountCurrent);

    /**
     * 查询二级分类收支
     */
    List<Double> selectSecondCategoryAllInEx(Map<String, Object> map);
}
