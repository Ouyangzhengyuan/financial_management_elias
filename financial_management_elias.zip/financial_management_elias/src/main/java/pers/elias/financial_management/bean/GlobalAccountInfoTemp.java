package pers.elias.financial_management.bean;

public class GlobalAccountInfoTemp extends GlobalAccountInfo{

}
