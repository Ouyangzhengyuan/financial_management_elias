package pers.elias.financial_management;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Test {
    public static void main(String[] args) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.set(2021, 9, 11);
        Date nowDate = cal.getTime();
        cal.set(2021, 9, 9);
        Date createdDate = cal.getTime();
        long timeNow = 0;
        long timeCreated = 0;
        try {
            cal.setTime(simpleDateFormat.parse(simpleDateFormat.format(nowDate)));
            timeNow = cal.getTimeInMillis();
            cal.setTime(simpleDateFormat.parse(simpleDateFormat.format(createdDate)));
            timeCreated = cal.getTimeInMillis();
        } catch (Exception e) {
            e.printStackTrace();
        }
        long between_days = (timeNow - timeCreated) / (1000 * 3600 * 24);
        if(between_days == 0){
            between_days = 1;
        }
        System.out.println(Integer.parseInt(String.valueOf(between_days)));
    }
}
