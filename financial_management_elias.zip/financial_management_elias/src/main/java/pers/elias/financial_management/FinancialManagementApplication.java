package pers.elias.financial_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancialManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(FinancialManagementApplication.class, args);
    }
}
